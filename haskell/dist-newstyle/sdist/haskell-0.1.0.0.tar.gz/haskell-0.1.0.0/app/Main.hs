{-# LANGUAGE ImportQualifiedPost #-}
{-# LANGUAGE OverloadedStrings #-}

import Control.Concurrent (forkIO)
import Control.Monad (forever)
import Data.Aeson (FromJSON, decode, withObject, (.:))
import Data.Aeson.Key (fromString)
import Data.ByteString.Lazy qualified as BL
import Data.Map qualified as Map
import Data.Maybe (fromMaybe)
import Data.PSQueue (PSQ)
import Data.PSQueue qualified as PSQ
import Data.Text (pack)
import Data.Text.Encoding (encodeUtf8)
import Data.Vector (Vector, (!))
import qualified Data.Vector as V
import Network.Socket
import System.IO

-- Estructura para recibir los datos
data InputData = InputData
  { coordenadaJugador :: (Int, Int), -- (columna, fila)
    coordenadaEnemigo :: (Int, Int),
    matrix :: Vector (Vector Int)
  }
  deriving (Show)

instance FromJSON InputData where
  parseJSON = withObject "InputData" $ \v -> do
    jugador <- v .: fromString "coordenadaJugador"
    enemigo <- v .: fromString "coordenadaEnemigo"
    matrix <- v .: fromString "matrix"
    return InputData {coordenadaJugador = jugador, coordenadaEnemigo = enemigo, matrix = V.fromList $ map V.fromList matrix}

-- Coordenadas adyacentes (arriba, abajo, izquierda, derecha)
adjacentCoords :: (Int, Int) -> [(Int, Int)]
adjacentCoords (x, y) = [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]

-- Heurística: distancia Manhattan
manhattanDistance :: (Int, Int) -> (Int, Int) -> Int
manhattanDistance (x1, y1) (x2, y2) = abs (x1 - x2) + abs (y1 - y2)

-- Implementación básica del algoritmo A*
aStar :: (Int, Int) -> (Int, Int) -> Vector (Vector Int) -> Handle -> IO ()
aStar jugador enemigo matriz handle = do
  let openSet = PSQ.singleton jugador (manhattanDistance jugador enemigo)
      cameFrom = Map.empty
      gScore = Map.singleton jugador 0
      fScore = Map.singleton jugador (manhattanDistance jugador enemigo)
  astarHelper openSet cameFrom gScore fScore enemigo matriz handle

astarHelper :: PSQ (Int, Int) Int -> Map.Map (Int, Int) (Int, Int) -> Map.Map (Int, Int) Int -> Map.Map (Int, Int) Int -> (Int, Int) -> Vector (Vector Int) -> Handle -> IO ()
astarHelper openSet cameFrom gScore fScore objetivo matriz handle
  | PSQ.null openSet = putStrLn "No se encontró ruta."
  | current == objetivo = do
      let ruta = reconstruirRuta cameFrom current
      putStrLn "Ruta encontrada:"
      print ruta
      enviarRutaARemote ruta handle -- Enviar la ruta al cliente
  | otherwise = do
      let openSet' = PSQ.deleteMin openSet
          vecinos = filter (esTransitable matriz) (adjacentCoords current)
      let (newOpenSet, newCameFrom, newGScore, newFScore) = foldl (procesarVecino current objetivo gScore fScore) (openSet', cameFrom, gScore, fScore) vecinos
      astarHelper newOpenSet newCameFrom newGScore newFScore objetivo matriz handle
  where
    current = PSQ.key (fromMaybe (error "Error con PSQ") (PSQ.findMin openSet))

-- Verifica si una coordenada es transitable en la matriz
esTransitable :: Vector (Vector Int) -> (Int, Int) -> Bool
esTransitable matriz (x, y) =
  let valor = matriz ! y ! x
   in valor == 3 || valor == -1

-- Procesar vecino (verifica si el vecino mejora la ruta actual)
procesarVecino :: (Int, Int) -> (Int, Int) -> Map.Map (Int, Int) Int -> Map.Map (Int, Int) Int -> (PSQ (Int, Int) Int, Map.Map (Int, Int) (Int, Int), Map.Map (Int, Int) Int, Map.Map (Int, Int) Int) -> (Int, Int) -> (PSQ (Int, Int) Int, Map.Map (Int, Int) (Int, Int), Map.Map (Int, Int) Int, Map.Map (Int, Int) Int)
procesarVecino current objetivo _ _ (openSet, cameFrom, gScore', fScore') vecino =
  let tentativeGScore = fromMaybe (maxBound :: Int) (Map.lookup current gScore') + 1
   in if tentativeGScore < fromMaybe (maxBound :: Int) (Map.lookup vecino gScore')
        then
          let newCameFrom = Map.insert vecino current cameFrom
              newGScore = Map.insert vecino tentativeGScore gScore'
              newFScore = Map.insert vecino (tentativeGScore + manhattanDistance vecino objetivo) fScore'
              newOpenSet = PSQ.insert vecino (tentativeGScore + manhattanDistance vecino objetivo) openSet
           in (newOpenSet, newCameFrom, newGScore, newFScore)
        else (openSet, cameFrom, gScore', fScore')

-- Reconstruir la ruta desde el objetivo hasta el inicio
reconstruirRuta :: Map.Map (Int, Int) (Int, Int) -> (Int, Int) -> [(Int, Int)]
reconstruirRuta cameFrom current
  | Map.member current cameFrom = current : reconstruirRuta cameFrom (fromMaybe (0, 0) (Map.lookup current cameFrom))
  | otherwise = [current]

-- Función para enviar la ruta al cliente
enviarRutaARemote :: [(Int, Int)] -> Handle -> IO ()
enviarRutaARemote ruta handle = do
  let rutaFormato = map (\(x, y) -> [x, y]) ruta
  let rutaTexto = show rutaFormato
  hPutStrLn handle rutaTexto

-- Función para leer datos desde el cliente y procesarlos
handleClient :: Handle -> IO ()
handleClient handle = do
  -- Leer datos enviados por el cliente
  dataLine <- hGetLine handle
  putStrLn "Conexión establecida con el cliente Python"

  -- Decodificar el JSON
  let maybeData = decode (BL.fromStrict (encodeUtf8 (pack dataLine))) :: Maybe InputData
  case maybeData of
    Just inputData -> do
      aStar (coordenadaJugador inputData) (coordenadaEnemigo inputData) (matrix inputData) handle
      handleClient handle -- Volver a esperar datos
    Nothing -> putStrLn "Error: No se pudo decodificar la cadena recibida."

main :: IO ()
main = withSocketsDo $ do
  -- Obtener la información de la dirección del servidor
  addrinfos <- getAddrInfo (Just (defaultHints {addrFlags = [AI_PASSIVE]})) Nothing (Just "3000")
  let serveraddr = head addrinfos

  -- Crear y enlazar el socket
  sock <- socket (addrFamily serveraddr) Stream defaultProtocol
  bind sock (addrAddress serveraddr)
  listen sock 1

  putStrLn "Servidor Haskell esperando conexiones..."

  -- Bucle infinito para aceptar conexiones
  forever $ do
    -- Aceptar la conexión del cliente
    (conn, _) <- accept sock
    handle <- socketToHandle conn ReadWriteMode
    hSetBuffering handle LineBuffering

    putStrLn "Conexión establecida con un cliente."

    -- Procesar la conexión con el cliente en un hilo separado
    _ <- forkIO $ handleClient handle

    return ()
